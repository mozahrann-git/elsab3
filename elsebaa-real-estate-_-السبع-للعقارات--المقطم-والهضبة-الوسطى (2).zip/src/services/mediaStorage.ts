/*
  رفع الصور والفيديوهات على Firebase Storage بدل تخزينها داخل Firestore.
  السبب: Firestore بيرفض أي مستند أكبر من 1 ميجا، وده اللي كان بيخلي الحفظ يفشل
  ويضيّع الصور. دلوقتي الملف بيترفع على Storage، وFirestore بيخزن الرابط بس.
*/
import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getStorage, FirebaseStorage, ref, uploadBytes, uploadString, getDownloadURL } from 'firebase/storage';
import { getAuth, signInAnonymously } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

function getAppInstance(): FirebaseApp {
  return getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
}

let storageInstance: FirebaseStorage | null = null;

function getStorageInstance(): FirebaseStorage {
  if (!storageInstance) {
    const app = getAppInstance();
    const bucket = (firebaseConfig as any).storageBucket;
    storageInstance = bucket ? getStorage(app, `gs://${bucket}`) : getStorage(app);
  }
  return storageInstance;
}

async function ensureStorageAuth(): Promise<void> {
  try {
    const app = getAppInstance();
    const auth = getAuth(app);
    if (!auth.currentUser) {
      await signInAnonymously(auth);
    }
  } catch (err) {
    console.warn('[Storage] Auth notice:', err);
  }
}

const safe = (s: string) => (s || 'general').replace(/[^\w\u0600-\u06FF-]/g, '_').slice(0, 40);
const stamp = () => `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

/** رفع ملف (صورة أو فيديو) والرجوع برابط مباشر */
export async function uploadFile(file: File, folder: string, id: string): Promise<string> {
  await ensureStorageAuth();
  const storage = getStorageInstance();
  const ext = (file.name.split('.').pop() || 'bin').toLowerCase();
  const path = `${folder}/${safe(id)}/${stamp()}.${ext}`;
  const snap = await uploadBytes(ref(storage, path), file, { contentType: file.type || undefined });
  return getDownloadURL(snap.ref);
}

/** رفع صورة موجودة كـ base64 (من الحفظ القديم) والرجوع برابط */
export async function uploadDataUrl(dataUrl: string, folder: string, id: string): Promise<string> {
  await ensureStorageAuth();
  const storage = getStorageInstance();
  const mime = (dataUrl.match(/^data:([^;]+);/) || [])[1] || 'image/jpeg';
  const ext = mime.includes('png') ? 'png' : mime.includes('webp') ? 'webp' : mime.startsWith('video') ? 'mp4' : 'jpg';
  const path = `${folder}/${safe(id)}/${stamp()}.${ext}`;
  const snap = await uploadString(ref(storage, path), dataUrl, 'data_url');
  return getDownloadURL(snap.ref);
}

/** لو الحاجة base64 بترفعها وترجع الرابط، ولو فشل الرفع تحتفظ بالصورة علشان متضيعش */
export async function ensureUploaded(value: string, folder: string, id: string): Promise<string> {
  if (!value || !value.trim()) return '';
  if (!value.startsWith('data:')) return value;
  try {
    const uploadedUrl = await uploadDataUrl(value, folder, id);
    return uploadedUrl || value;
  } catch (err) {
    console.error('[Storage] فشل رفع الملف إلى Storage، سيتم الاحتفاظ بالصورة:', err);
    return value;
  }
}